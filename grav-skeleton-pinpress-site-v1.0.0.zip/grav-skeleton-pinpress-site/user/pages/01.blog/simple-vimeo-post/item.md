---
title: Simple vimeo post
date: 17:34 08/24/2014
taxonomy:
    category: blog
    tag: [vimeo, advertising]
vimeo: http://player.vimeo.com/video/24517460?vq=medium&rel=0
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla elementum viverra pharetra. Nulla facilisis, sapien non pharetra venenatis, tortor erat tempus est, sed accumsan odio ante ac elit. Nulla hendrerit a est vel ornare. Proin eu sapien a sapien dignissim feugiat non eget turpis. Proin at accumsan risus. Pellentesque nunc diam, congue ac lacus nec, volutpat tincidunt turpis. Lorem...Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla elementum viverra pharetra. Nulla facilisis, sapien non pharetra venenatis, tortor erat tempus est, sed accumsan odio ante ac elit. Nulla hendrerit a est vel ornare. Proin eu sapien a sapien dignissim feugiat non eget turpis. Proin at accumsan risus. Pellentesque nunc diam, congue ac lacus nec, volutpat tincidunt turpis. Lorem...Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla elementum viverra pharetra. Nulla facilisis, sapien non pharetra venenatis, tortor erat tempus est, sed accumsan odio ante ac elit. Nulla hendrerit a est vel ornare. Proin eu sapien a sapien dignissim feugiat non eget turpis. Proin at accumsan risus. Pellentesque nunc diam, congue ac lacus nec, volutpat tincidunt turpis. Lorem...Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla elementum viverra pharetra. Nulla facilisis, sapien non pharetra venenatis, tortor erat tempus est, sed accumsan odio ante ac elit. Nulla hendrerit a est vel ornare. Proin eu sapien a sapien dignissim feugiat non eget turpis. Proin at accumsan risus. Pellentesque nunc diam, congue ac lacus nec, volutpat tincidunt turpis. Lorem...
