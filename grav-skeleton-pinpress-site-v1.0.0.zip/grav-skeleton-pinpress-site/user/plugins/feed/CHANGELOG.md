# v1.4.1
## 10/07/2015

1. [](#bugfix)
    * Avoid duplicated routes

# v1.4.0
## 08/26/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.3.3
## 03/24/2015

1. [](#improved)
    * Feed will now skip pages with `feed: skip: true` in frontmatter
1. [](#bugfix)
    * Fixed page overrides for configuration

# v1.3.2
## 02/19/2015

1. [](#bugfix)
    * Fixed couple of RSS validation issues

# v1.3.1
## 12/26/2014

1. [](#bugfix)
    * Fixed issue with default configuration not being loaded yet

# v1.3.0
## 11/30/2014

1. [](#new)
    * ChangeLog started...
