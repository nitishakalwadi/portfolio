# v1.6.2
## 01/06/2016

1. [](#improved)
    * Improved the README instructions on how to save all pages 

# v1.6.1
## 11/11/2015

1. [](#improved)
    * Strip HTML tags from title and content before searching

# v1.6.0
## 11/11/2015

1. [](#new)
    * Removing `filter:` from configuration will search **ALL** pages

# v1.5.1
## 10/15/2015

1. [](#improved)
    * Minor performance fix
    * Updated README.md with more help
1. [](#bugfix)
    * Fix for special character searches    

# v1.5.0
## 10/07/2015

1. [](#new)
    * Allow simplesearch to work with on-page collections

# v1.4.1
## 08/31/2015

1. [](#improved)
    * Fixed some blueprint issues

# v1.4.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin
    * Added results sorting

# v1.3.0
## 07/21/2015

1. [](#new)
    * Added support for modular pages in results

# v1.2.7
## 07/17/2015

1. [](#bugfix)
    * Fixed "Undefined index: extension" error

# v1.2.6
## 07/14/2015

1. [](#bugfix)
    * Fixed URL issue that showed up with multi-languages

# v1.2.5
## 04/24/2015

1. [](#bugfix)
    * Fixed issue with broken image

# v1.2.4
## 02/19/2015

2. [](#improved)
    * Implemented new `param_sep` variable from Grav 0.9.18

# v1.2.3
## 01/06/2015

1. [](#improved)
    * Improved `README.md` file with more information

# v1.2.2
## 12/21/2014

1. [](#bugfix)
    * Fix for invalid base_url in some instances

# v1.2.1
## 11/30/2014

1. [](#new)
    * ChangeLog started...
