# v1.1.0
## 01/06/2016

1. [](#bugfix)
    * Responsive fix
    * Fix for continue link
    * Fix for ordered list styling
    * Fix for related pages item links

# v1.0.0
## 12/03/2015

1. [](#new)
    * ChangeLog started...
