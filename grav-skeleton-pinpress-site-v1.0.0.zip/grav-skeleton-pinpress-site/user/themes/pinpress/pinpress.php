<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Pinpress extends Theme
{

}
